Chapter 10 Programs:

particleSystem: particles in box with repulsion, gravity, restitution

particleSystem2 and particleSystem3: particle system using shaded point sprites

particleDiffusion1: randomly moving  particles leaving colors at their positions which are diffused on successive frames.

particleDiffusion2: same particle system but particles look at their environment and depending on their color and color at new location move to x or y axis.

particlediffusion5: Particles are added over time from two fixed points. Each particle is rendered as a black dot. Colors show diffusion of each particle’s position.

particleDiffusion9: Single type of particle edited from a fixed point. There is an area in the middle which particles cannot enter.

mandelbrot1: mandelbrot set generating program. Note computation of membership in the Mandelbrot set is done in the fragment shader

mandelbrot2: interactive mandelbrot set generating program.